<!DOCTYPE html>
<html>
<head>
	<title>SKILL TEST CENTER with boot</title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="home.css">

</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-sm-6 ">
				<br><h1>Welcome</h1>
				<p class="text">Skill test center</p>
				<p>learn free cources of html , css and more! </p><br>
				<a class="btn btn-first" href="./login.html">Login</a>
				<a class="btn sec-second" href="./register.html">Registration</a><br>
				<a class="btn btn-third" href="./courses.html">Learn<span class="badge badge-danger">New</span></a>

			</div>
			<div class="col-sm-6 ">
				<br><img src="home_cover_image.png" class="img-responsive">
				
			</div>
			
		</div>
	</div>
</body>
</html>