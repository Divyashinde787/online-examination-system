-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2021 at 11:41 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stc`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `id` int(11) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL,
  `option_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`id`, `question_id`, `users_id`, `option_id`) VALUES
(1, 1, 1, 1),
(2, 1, 15, 2),
(3, 3, 15, 9),
(4, 4, 15, 15),
(5, 1, 15, 2),
(6, 3, 15, 9),
(7, 4, 15, 15),
(8, 1, 15, 1),
(9, 4, 15, 15),
(10, 1, 15, 1),
(11, 2, 15, 7),
(12, 4, 15, 15),
(13, 1, 15, 1),
(14, 2, 15, 7),
(15, 1, 15, 1),
(16, 2, 15, 6),
(17, 4, 15, 13),
(18, 1, 15, 1),
(19, 2, 15, 6),
(20, 4, 15, 13),
(21, 1, 15, 1),
(22, 2, 15, 6),
(23, 4, 15, 13),
(24, 1, 15, 1),
(25, 2, 15, 6),
(26, 4, 15, 13),
(27, 1, 15, 1),
(28, 2, 15, 7),
(29, 3, 15, 12),
(30, 4, 15, 13),
(31, 5, 15, 20),
(32, 1, 15, 1),
(33, 2, 15, 7),
(34, 3, 15, 12),
(35, 4, 15, 13),
(36, 5, 15, 20),
(37, 1, 15, 1),
(38, 2, 15, 7),
(39, 3, 15, 12),
(40, 4, 15, 13),
(41, 5, 15, 20),
(42, 1, 15, 1),
(43, 2, 15, 7),
(44, 3, 15, 12),
(45, 4, 15, 13),
(46, 5, 15, 20),
(47, 1, 15, 1),
(48, 2, 15, 7),
(49, 3, 15, 12),
(50, 4, 15, 13),
(51, 5, 15, 20),
(52, 1, 15, 1),
(53, 2, 15, 7),
(54, 3, 15, 12),
(55, 4, 15, 13),
(56, 5, 15, 20),
(57, 1, 15, 1),
(58, 2, 15, 7),
(59, 3, 15, 12),
(60, 4, 15, 13),
(61, 5, 15, 20),
(62, 1, 15, 1),
(63, 2, 15, 7),
(64, 3, 15, 12),
(65, 4, 15, 13),
(66, 5, 15, 20),
(67, 1, 15, 1),
(68, 2, 15, 7),
(69, 3, 15, 12),
(70, 4, 15, 13),
(71, 5, 15, 20),
(72, 1, 15, 1),
(73, 2, 15, 7),
(74, 3, 15, 12),
(75, 4, 15, 13),
(76, 5, 15, 20),
(77, 1, 15, 1),
(78, 2, 15, 7),
(79, 3, 15, 12),
(80, 4, 15, 13),
(81, 5, 15, 20),
(82, 1, 15, 1),
(83, 2, 15, 7),
(84, 3, 15, 12),
(85, 4, 15, 13),
(86, 5, 15, 20),
(87, 1, 15, 1),
(88, 2, 15, 7),
(89, 3, 15, 12),
(90, 4, 15, 13),
(91, 5, 15, 20),
(92, 1, 15, 1),
(93, 2, 15, 7),
(94, 3, 15, 12),
(95, 4, 15, 13),
(96, 5, 15, 20),
(97, 1, 15, 1),
(98, 2, 15, 7),
(99, 3, 15, 12),
(100, 4, 15, 13),
(101, 5, 15, 20),
(102, 1, 15, 1),
(103, 2, 15, 7),
(104, 3, 15, 12),
(105, 4, 15, 14),
(106, 5, 15, 18),
(107, 1, 15, 1),
(108, 2, 15, 7),
(109, 3, 15, 12),
(110, 4, 15, 14),
(111, 5, 15, 18),
(112, 1, 15, 1),
(113, 2, 15, 7),
(114, 3, 15, 12),
(115, 4, 15, 14),
(116, 5, 15, 18),
(117, 1, 15, 1),
(118, 2, 15, 7),
(119, 5, 15, 20),
(120, 1, 15, 1),
(121, 2, 15, 6),
(122, 5, 15, 20),
(123, 1, 15, 1),
(124, 5, 15, 18),
(125, 1, 15, 1),
(126, 2, 15, 7),
(127, 3, 15, 12),
(128, 4, 15, 15),
(129, 5, 15, 19),
(130, 1, 15, 1),
(131, 2, 15, 7),
(132, 3, 15, 12),
(133, 4, 15, 15),
(134, 5, 15, 20),
(135, 1, 15, 1),
(136, 2, 15, 6),
(137, 3, 15, 10),
(138, 4, 15, 15),
(139, 5, 15, 20),
(140, 1, 16, 1),
(141, 2, 16, 8),
(142, 3, 16, 12),
(143, 4, 16, 15),
(144, 5, 16, 20),
(145, 1, 17, 4),
(146, 2, 17, 5),
(147, 3, 17, 12),
(148, 4, 17, 15),
(149, 5, 17, 18),
(150, 6, 17, 21),
(151, 7, 17, 27),
(152, 8, 17, 30),
(153, 9, 17, 33),
(154, 10, 17, 38),
(155, 6, 17, 21),
(156, 7, 17, 27),
(157, 8, 17, 30),
(158, 9, 17, 33),
(159, 10, 17, 38),
(160, 6, 17, 21),
(161, 7, 17, 27),
(162, 8, 17, 30),
(163, 9, 17, 33),
(164, 10, 17, 38),
(165, 10, 17, 37),
(166, 6, 17, 21),
(167, 7, 17, 27),
(168, 8, 17, 30),
(169, 9, 17, 33),
(170, 10, 17, 37),
(181, 6, 17, 21),
(182, 7, 17, 27),
(183, 8, 17, 30),
(184, 9, 17, 33),
(185, 10, 17, 38),
(186, 6, 17, 21),
(187, 7, 17, 27),
(188, 8, 17, 30),
(189, 9, 17, 33),
(190, 10, 17, 38),
(191, 6, 17, 21),
(192, 7, 17, 27),
(193, 8, 17, 30),
(194, 9, 17, 33),
(195, 10, 17, 38),
(196, 6, 17, 21),
(197, 7, 17, 27),
(198, 8, 17, 30),
(199, 9, 17, 33),
(200, 10, 17, 38),
(201, 6, 17, 21),
(202, 7, 17, 27),
(203, 8, 17, 30),
(204, 9, 17, 33),
(205, 10, 17, 38),
(206, 6, 17, 21),
(207, 7, 17, 27),
(208, 8, 17, 30),
(209, 9, 17, 33),
(210, 10, 17, 38),
(211, 6, 17, 21),
(212, 7, 17, 27),
(213, 8, 17, 30),
(214, 9, 17, 33),
(215, 10, 17, 38),
(216, 6, 17, 21),
(217, 7, 17, 27),
(218, 8, 17, 30),
(219, 9, 17, 33),
(220, 10, 17, 38),
(221, 6, 17, 21),
(222, 7, 17, 27),
(223, 8, 17, 30),
(224, 9, 17, 33),
(225, 10, 17, 38),
(226, 6, 17, 21),
(227, 7, 17, 27),
(228, 8, 17, 30),
(229, 9, 17, 33),
(230, 10, 17, 38),
(231, 6, 17, 21),
(232, 7, 17, 27),
(233, 8, 17, 30),
(234, 9, 17, 33),
(235, 10, 17, 39),
(236, 6, 17, 22),
(237, 7, 17, 27),
(238, 8, 17, 30),
(239, 9, 17, 33),
(240, 10, 17, 39),
(241, 6, 17, 22),
(242, 7, 17, 27),
(243, 8, 17, 30),
(244, 9, 17, 33),
(245, 10, 17, 39),
(246, 6, 17, 22),
(247, 7, 17, 27),
(248, 8, 17, 30),
(249, 9, 17, 33),
(250, 10, 17, 39),
(251, 6, 17, 22),
(252, 7, 17, 27),
(253, 8, 17, 30),
(254, 9, 17, 33),
(255, 10, 17, 38);

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(100) NOT NULL,
  `users_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `exam_name`, `users_id`) VALUES
(1, 'basichtml', 1),
(2, 'php', 14);

-- --------------------------------------------------------

--
-- Table structure for table `exam_attended`
--

CREATE TABLE `exam_attended` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `marks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exam_attended`
--

INSERT INTO `exam_attended` (`id`, `exam_id`, `student_id`, `marks`) VALUES
(6, 1, 15, 20),
(7, 1, 16, 30),
(8, 1, 17, 10),
(9, 2, 17, 40),
(10, 2, 17, 40),
(11, 2, 17, 40),
(12, 2, 17, 0),
(13, 2, 17, 0),
(14, 2, 17, 10),
(15, 2, 17, 0),
(16, 2, 17, 50),
(17, 2, 17, 0),
(18, 1, 0, 40),
(19, 1, 0, 40),
(20, 2, 17, 40),
(21, 2, 17, 40),
(22, 2, 17, 40),
(23, 2, 17, 40),
(24, 2, 17, 40),
(25, 2, 17, 40),
(26, 2, 17, 40),
(27, 2, 17, 40),
(28, 2, 17, 40),
(29, 2, 17, 40),
(30, 2, 17, 40),
(31, 2, 17, 30),
(32, 2, 17, 30),
(33, 2, 17, 30),
(34, 2, 17, 30);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `option` varchar(100) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer` enum('1','0') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `option`, `question_id`, `answer`) VALUES
(1, 'HyperText Markup Language ', 1, '1'),
(2, 'HighText Machine Language', 1, '0'),
(3, 'HyperText and links Markup Language', 1, '0'),
(4, 'None of these', 1, '0'),
(5, 'Head, Title, HTML, body', 2, '0'),
(6, 'Head, Title, body, HTML', 2, '0'),
(7, 'HTML, Head, Title, Body\r\n', 2, '1'),
(8, 'HTML, Body, Title, Head', 2, '0'),
(9, 'new line', 3, '0'),
(10, 'vertical ruler', 3, '0'),
(11, 'new paragraph', 3, '0'),
(12, 'horizontal ruler', 3, '1'),
(13, 'id', 4, '1'),
(14, 'class', 4, '0'),
(15, 'type', 4, '0'),
(16, 'None of these', 4, '0'),
(17, 'class', 5, '0'),
(18, 'type', 5, '0'),
(19, 'id', 5, '0'),
(20, 'style', 5, '1'),
(21, 'Hypertext Preprocessor', 6, '1'),
(22, 'Pretext Hypertext Preprocessor\r\n', 6, '0'),
(23, 'Personal Home Processor\r\n', 6, '0'),
(24, 'None of the above\r\n', 6, '0'),
(25, 'Drek Kolkevi\r\n', 7, '0'),
(26, 'List Barely', 7, '0'),
(27, 'Rasmus Lerdrof\r\n', 7, '1'),
(28, 'None of the above\r\n', 7, '0'),
(29, '! (Exclamation)', 8, '0'),
(30, '$ (Dollar)', 8, '1'),
(31, '& (Ampersand)', 8, '0'),
(32, '# (Hash)', 8, '0'),
(33, '.php\r\n', 9, '1'),
(34, '.html', 9, '0'),
(35, '.css', 9, '0'),
(36, '.xml', 9, '0'),
(37, 'Extern\r\n', 10, '1'),
(38, 'Local\r\n', 10, '0'),
(39, 'Static', 10, '0'),
(40, 'Global\r\n', 10, '0');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(11) NOT NULL,
  `question` varchar(100) NOT NULL,
  `exam_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `question`, `exam_id`) VALUES
(1, ' HTML stands for -', 1),
(2, 'The correct sequence of HTML tags for starting a webpage is ', 1),
(3, 'The \'hr\' tag in HTML is used for -\r\n', 1),
(4, 'Which of the following attribute is used to provide a unique name to an element?', 1),
(5, ' Which of the following HTML attribute is used to define inline styles?', 1),
(6, 'PHP stands for -', 2),
(7, 'Who is known as the father of PHP?', 2),
(8, 'Variable name in PHP starts with -', 2),
(9, 'Which of the following is the default file extension of PHP?', 2),
(10, 'Which of the following is not a variable scope in PHP?', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` char(60) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `role` enum('student','teacher') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `pass`, `role`) VALUES
(1, 'nikita shinde', 'nikitashinde@gmail.com', 'nik', 'teacher'),
(14, 'nik', 'nik@123.com', '123', 'teacher'),
(15, 'divya shinde', 'divyashinde787@gmail.com', '123', 'student'),
(16, 'pooja', 'pooja123@gmail.com', '1234', 'student'),
(17, 'nikhil', 'nikhil@gmail.com', '123', 'student'),
(18, 'nikhil', 'nikhil@gmail.com', '123', 'student'),
(19, 'nikhil', 'nikhil@gmail.com', '123', 'student'),
(20, 'nikhil', 'nikhil@gmail.com', '123', 'student'),
(21, 'nikhil', 'nikhil@gmail.com', '1234', 'teacher');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `option_id` (`option_id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`);

--
-- Indexes for table `exam_attended`
--
ALTER TABLE `exam_attended`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`),
  ADD KEY `exam_id` (`exam_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=256;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exam_attended`
--
ALTER TABLE `exam_attended`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`),
  ADD CONSTRAINT `answer_ibfk_2` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `answer_ibfk_3` FOREIGN KEY (`option_id`) REFERENCES `options` (`id`);

--
-- Constraints for table `exams`
--
ALTER TABLE `exams`
  ADD CONSTRAINT `exams_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
