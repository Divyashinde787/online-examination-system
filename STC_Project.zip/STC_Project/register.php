<?php

// check email & password is correct from DB
// get user role(teacher | student)
// set into session (read more)4

//include db.php page for database connection
include('./db.php');

if(!$_POST) {
	print_r("resgister first!");
	die;
}
$data = $_POST;
$data['email'] = str_replace(' ', '', $data['email']);
//var_dump($data['email']);
// insert into Users table

$query = "INSERT INTO `users` (`name`, `email`, `pass`, `role`) VALUES ('".$data['name']."', '".$data['email']."', '".$data['password']."', '".$data['role']."')";

$result=$conn->query($query);
If($result === 	TRUE)
{
//Echo "Record successfully inserted";

// page link

}
Else
{
Echo "There is some problem in inserting record";
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Registration Succesfully</h1>
<a href='login.html'>Back to Login page</a>
</body>
</html>

