<?php
session_start();
$user = $_SESSION['user'];

//include db.php page for database connection
include('./db.php');

// get Exam list
$query = "SELECT * fROM exams";
$result = mysqli_query($conn,$query);

// $db_data =mysqli_fetch_array($result);
// print_r($result);

$marks_query = "SELECT * from exam_attended where student_id='".$user['id']."'";
$marks_result = mysqli_query($conn,$marks_query);

?>
<html>
<head>
<style>
table
{
border-style:solid;
border-width:2px;
border-color:pink;
}
</style>
</head>
<body bgcolor="#EEFDEF">
	

<?php
echo "<table border='1'>
<tr>
<th>Id</th>
<th>Exam name</th>
<th>Action / Marks</th>
</tr// data 
?>";

// for($i=0; $i< count($db_data); $i++)
while($db_data= mysqli_fetch_array($result)) {
$db_data['marks'] = null;
	while($marks_data= mysqli_fetch_array($marks_result)) {
		if($marks_data['exam_id'] === $db_data['id']) {
			$db_data['marks'] = $marks_data['marks'];
		}
}
  
  	?>
  	
  	<tr>
  	<td><?php echo $db_data['id'];?></td>
   	<td><?php echo $db_data['exam_name'];?></td>
   	<?php 
   	if($db_data['marks']) {
   	?>
   	   	<td><?php echo $db_data['marks'];?></td>
<?php } else { ?>
	<td><a href='test_page.php?exam_id=<?php echo $db_data['id'];?>' target="_blank">START TEST</a></td></tr>
	
<?php } ?>

  <!-- echo "<tr>";
  echo "<td>" . $db_data['id'] . "</td>";
  echo "<td>" . $db_data['exam_name'] . "</td>";
  echo '<td><a href="test_page.php?exam_id=<?php echo $db_data['id'];?>" target="_blank">START TEST</a></td>';
  echo "</tr>"; -->
  <?php
  }
echo "</table>";
?>
</body>
</html>