<?php
 session_start();

#print_r($_SESSION);

$conn = mysqli_connect('localhost','root');
if($conn){
#echo "sucesss";
}
mysqli_select_db($conn, 'stc');

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

	<!-- Latest compiled CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">

<h1 class="text-center text-danger">Start Your Exam </h1>

<div class="col-lg-8 m-auto d-block">
<div class="card">

	<h1 class="text-center card-header"> Welcome , You have select only one out of four</h1>
</div><br>

<form action="test_submit_page.php" method="POST">
<?php 

$exam_id = $_GET['exam_id'] ?? 1;

$q = "select * from question where exam_id = '".$exam_id."'";
$query = mysqli_query($conn,$q);

?>
<!-- // exam_id -->
<input style="display: none" type="text" name="exam_id" value=" <?php echo $exam_id; ?>">
<?php		

while($rows= mysqli_fetch_array($query)) {
?>
 <div class="card">
 	<h4 class="card-header"> <?php echo $rows['question'] ?> </h4>
 
 	<?php 
	 	$q = "select * from options where question_id = '".$rows['id']."'";
		$check1_res = mysqli_query($conn, $q);
		?>


		<?php

		while($rows= mysqli_fetch_array($check1_res,MYSQLI_ASSOC)) {
						?>

			<div class="card-body">

				<input style="display: none" type="text" name="ans[<?php echo $rows['id']; ?>]" value=" <?php echo $rows['answer']; ?>">
				
				<input type="radio" name="checkans[<?php echo $rows['question_id']; ?>]" value=" <?php echo $rows['id']; ?>">

				<?php echo $rows['option'] ?>
			</div>
<?php
	 }
	}
?>
<input type="submit" name="submit" value="Submit" class="btn btn-success m-auto d-block"><br>
</form>
</div>
</div><br>
	<div class="text-center">
	<a href="home.php" class="btn-btn-first m-auto d-block" style="background-color: #e34829;color: #fff; ">LOGOUT</a><br>       
	</div>
<div>
	<h5 class="text-center">@2021 All Rights Reserved.</h5><br>
</div><br>
</div>
</body>
</html>