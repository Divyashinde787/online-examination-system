<?php

	$host = "localhost";
	$dbusername = "root";
	$dbpassword="";
	$dbname="stc";

	//create connection
	$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

	if(mysqli_connect_error())
	{
	 die('Connection Error('.mysqli_connect_error().')'.mysqli_connect_error());
	}
	else
	{
		return true;
	}
?>