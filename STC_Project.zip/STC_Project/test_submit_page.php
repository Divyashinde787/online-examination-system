<?php
session_start();

// check email & password is correct from DB
// get user role(teacher | student)
// set into session (read more)4

//include db.php page for database connection
include('./db.php');

if(!$_POST) {
	print_r("submit first!");
	die;
}
$data = $_POST;
$exam_id = $data['exam_id'];

#var_dump($data['ans']);
#print_r($_SESSION);
$ans = $data['ans'];

$user = $_SESSION['user'];
$marks = 0;
foreach($data['checkans'] as $key => $val) {

	$query = "INSERT INTO `answer` (`question_id`, `users_id`, `option_id`) VALUES ('".$key."', '".$user['id']."', '".$val."')";

	$result=$conn->query($query);
	If($result === 	TRUE)
	{
	#Echo "Record successfully inserted";
	}
	Else
	{
	#Echo "There is some problem in inserting record";
	}

	if((int)$ans[(int)$val] === 1) {
		$marks += 10;
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Latest compiled CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
	  <link rel="stylesheet" href="test_submit_page.css">
	<title></title>
</head>
<body>
	<br><div>
	<center><h1>Congratulations your marks are <?php echo $marks; ?></h1>
<a href='student_dashboard.php'>Back to Dashboard</a></center>
<br>
<br>

</div>
<br><div class="footer-basic">
      <br>  <footer>
            <div class="social"><a href="https://www.instagram.com"><i class="icon ion-social-instagram"></i></a><a href="https://www.snapchat.com"><i class="icon ion-social-snapchat"></i></a><a href="https://www.twitter.com"><i class="icon ion-social-twitter"></i></a><a href="https://www.facebook.com/"><i class="icon ion-social-facebook"></i></a></div>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="./home.php">Home</a></li>
                <li class="list-inline-item"><a href="./courses.html">Courses</a></li>
                <li class="list-inline-item"><a href="#">About</a></li>
                <li class="list-inline-item"><a href="./instruction.html">Instruction</a></li>
            </ul>
            <p class="copyright">Copyright © 2021</p>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php 

	$query = "INSERT INTO `exam_attended` (`exam_id`, `student_id`, `marks`) VALUES ('".$exam_id."', '".$user['id']."', '".$marks."')";

	$conn->query($query);
?>