<?php
 session_start();

// check email & password is correct from DB
// get user role(teacher | student)
// set into session (read more)4

include('./db.php');
$data = $_POST;

//print_r($data);


// check is email & password is correct
$query = "SELECT email, pass, role, id fROM users WHERE email = '".$data['email']."' Limit 1";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
  // output data of each row
	$db_data = $result->fetch_assoc();

	// check password
	if($data['password'] == $db_data['pass']) {
		  	$_SESSION["user"] = $db_data;

		// login
		if($db_data['role'] === 'teacher') {
			#print_r("this is teacher");
			// set into session
			#session
  			$_SESSION["user"] = $db_data;   

		} else {
			// print_r("this is student");
			// set into session

			// student dashbord
  			header("Location: ./student_dashboard.php");
  			#session
  			$_SESSION["user"] = $db_data;   
			exit;
		}
	}
} else {
  echo "0 results";
}
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
	<header class="header" style="height: 10vh;">
		<nav class="navbar navbar-style" style="background-color: #e80c0c;">
		 	<ul class="nav navbar-nav"><li><a href="./home.php">Home</a></li></ul>
		</nav>
	</header>
	<h1>This is Teacher</h1>
<a href='home.php'>Back to Dashboard</a>
</body>
</html>
